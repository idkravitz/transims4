//*********************************************************
//	Read_Household.cpp - Read the Household List and Data Files
//*********************************************************

#include "Router.hpp"
#include "Utility.hpp"
#include "Household_File.hpp"

//---------------------------------------------------------
//	Read_Household
//---------------------------------------------------------

void Router::Read_Household (void)
{
	int hhold, type;

	Household_Data hh_rec, *hh_ptr;
	Household_File *hhold_file;

	household_array = new Household_Array ();

	//---- initialize the hhold data ----

	if (hhlist_flag) {
		nhh_list = hhlist_file.Num_Records ();

		if (nhh_list == 0) {
			Error ("No Household List Records");
		}

		if (!household_data.Max_Records (nhh_list)) {
			Error ("Insufficient Memory for %d Household List Records", nhh_list);
		}

		Show_Message ("Reading %s -- Record", hhlist_file.File_Type ());
		Set_Progress ();

		//---- store the household list ----

		while (hhlist_file.Read ()) {
			Show_Progress ();

			Get_Integer (hhlist_file.Record (), &hhold);

			if (hhold <= 0) continue;

			hh_rec.Household (hhold);
			hh_rec.Type (0);

			if (!household_data.Add (&hh_rec)) {
				Error ("Adding Household %d", hhold);
			}
		}
		End_Progress ();

		hhlist_file.Close ();

		Print (2, "Number of Household List Records = %d", Progress_Count ());

		nhh_list = household_data.Num_Records ();

		household_data.Max_Records (nhh_list);
	}

	if (!hhold_flag) return;

	hhold_file = (Household_File *) Demand_Db_Base (HOUSEHOLD);
	Demand_File_False (HOUSEHOLD);

	if (!hhlist_flag) {
		hhold = hhold_file->Estimate_Records ();

		if (hhold == 0) {
			Error ("No Household Records");
		}
		if (!household_data.Max_Records (hhold)) {
			Error ("Insufficient Memory for %d Household Records", hhold);
		}
	}

	Show_Message ("Reading %s -- Record", hhold_file->File_Type ());
	Set_Progress (50000);

	//---- store the household list ----

	while (hhold_file->Read ()) {
		Show_Progress ();

		hhold = hhold_file->Household ();

		if (hhold <= 0) continue;

		if (hhlist_flag) {
			hh_ptr = household_data.Get (hhold);
			if (hh_ptr == NULL) continue;
		} else {
			hh_rec.Household (hhold);
			hh_ptr = &hh_rec;
		}
		hhold_file->Get_Field (type_fld, &type);

		hh_ptr->Type (hhold_range.In_Index (type));

		if (hh_ptr->Type () == 0) {
			Error ("Household %d Type Value %d is Not in Break Point Range", hhold, type);
		}
		if (!hhlist_flag && !household_data.Add (hh_ptr)) {
			Error ("Adding Household %d", hhold);
		}
	}
	End_Progress ();

	hhold_file->Close ();

	Print (2, "Number of Household Records = %d", Progress_Count ());

	//---- scan the household list ----

	if (hhlist_flag) {
		for (hh_ptr = household_data.First (); hh_ptr != NULL; hh_ptr = household_data.Next ()) {
			if (hh_ptr->Type () == 0) {
				Error ("A Household Record was Not Found for Household %d", hh_ptr->Household ());
			}
		}
	} else {
		household_data.Max_Records (household_data.Num_Records ());
	}
}
