//*********************************************************
//	Router.hpp - Network Path Builder
//*********************************************************

#ifndef ROUTER_HPP
#define ROUTER_HPP

#include "Demand_Service.hpp"
#include "Problem_Service.hpp"
#include "Random.hpp"
#include "Time_Step.hpp"
#include "Integer_Array.hpp"
#include "Data_Range.hpp"
#include "Equation.hpp"

#include "Plan_File.hpp"
#include "Trip_File.hpp"
#include "Problem_File.hpp"
#include "Db_File.hpp"

#include "Data/Path_Data.hpp"
#include "Data/Trip_End_Data.hpp"
#include "Data/Connect_Dir_Data.hpp"
#include "Data/No_Turn_Data.hpp"
#include "Data/List_Data.hpp"
#include "Data/Park_Ride_Data.hpp"
#include "Data/Route_Stop_Data.hpp"

#define MAX_PATHS	10

//---------------------------------------------------------
//	Router - execution class definition
//---------------------------------------------------------

class Router : public Demand_Service, public Problem_Service
{
public:

	Router (void);
	virtual ~Router (void);

	virtual void Execute (void);

protected:

	static char * HOUSEHOLD_LIST;
	static char * TRIP_FILE;
	static char * ACTIVITY_FILE;
	static char * TIME_OF_DAY_FORMAT;
	static char * PLAN_FILE;
	static char * PLAN_FORMAT;
	static char * NODE_LIST_PATHS;
	static char * ROUTE_SELECTED_MODES;
	static char * ROUTE_WITH_SPECIFIED_MODE;
	static char * LIMIT_PARKING_ACCESS;
	static char * WALK_PATH_DETAILS;
	static char * IGNORE_TIME_CONSTRAINTS;
	static char * IGNORE_ROUTING_PROBLEMS;
	static char * PERCENT_RANDOM_IMPEDANCE;
	static char * RANDOM_NUMBER_SEED;
	static char * HOUSEHOLD_TYPE_FIELD;
	static char * HOUSEHOLD_TYPE_BREAK_POINTS;
	static char * WALK_SPEED;
	static char * BICYCLE_SPEED;
	static char * WALK_TIME_VALUE;
	static char * BICYCLE_TIME_VALUE;
	static char * FIRST_WAIT_VALUE;
	static char * TRANSFER_WAIT_VALUE;
	static char * VEHICLE_TIME_VALUE;
	static char * DISTANCE_VALUE;
	static char * COST_VALUE;
	static char * TRANSFER_PENALTY;
	static char * RAIL_BIAS_FACTOR;
	static char * MAX_WALK_DISTANCE;
	static char * MAX_BICYCLE_DISTANCE;
	static char * MAX_WAIT_TIME;
	static char * MAX_NUMBER_OF_TRANSFERS;
	static char * MAX_NUMBER_OF_PATHS;
	static char * MAX_PARK_RIDE_PERCENTAGE;
	static char * MAX_LEGS_PER_PATH;
	static char * MAX_CIRCUITY_RATIO;
	static char * MIN_CIRCUITY_DISTANCE;
	static char * MAX_CIRCUITY_DISTANCE;
	static char * MAX_LINK_DELAY_ERRORS;
	static char * LINK_DELAY_UPDATE_RATE;
	static char * EQUATION_PARAMETERS_x;
	static char * PROBLEM_FILE;
	static char * PROBLEM_FORMAT;
	static char * MAX_ROUTING_PROBLEMS;	

	virtual void Program_Control (void);
	virtual bool Vehicle_Processing (Db_File *fh);

private:

	int nhh_list, nhh_proc, nrecord, nprocess, ntrips, ntransit, nmagic, nroute;
	int random_imped, max_tod, max_walk, max_bike, update_rate, nupdates, num_trips;

	bool walk_net, bike_net, drive_net, loc_net, transit_net, fare_flag;
	bool trip_flag, node_flag, delay_flag, zero_flag, wait_flag, update_flag, tod_flag;
	bool random_flag, walk_flag, bike_flag, hhlist_flag, hhold_flag, limit_access;
	bool save_plans, problem_flag, walk_detail, walk_active, distance_flag;
	bool select_mode [MAX_MODE], mode_flag, park_ride_flag, ignore_time, ignore_errors;
	bool time_flag, dist_flag, length_flag, wait_time_flag, access_flag , bias_flag;

	int rail_bias, xfer_imped, new_mode, max_delay_errors, leg_check;
	int value_round, value_roll, offset_round, offset_roll, time_period, type_fld;
	int max_distance, min_distance, max_wait, max_transfers, max_paths, max_parkride, max_ratio;
	int value_walk, value_bike, value_wait, value_xfer, value_time, value_distance, value_cost;
	double walk_speed, bike_speed, cap_factor;

	Random random;
	Time_Step trip_time;
	Data_Range hhold_range;
	Equation_Array equation;

	Db_File hhlist_file, activity_file;
	Trip_File trip_file;
	Problem_File problem_file;
	Plan_File plan_file;

	Integer_List walk_value, bike_value, wait_value, xfer_value, time_value, distance_value, cost_value;
	Integer_List walk_max, bike_max, wait_max, xfer_max, imped_xfer, path_max, bias_rail, parkride_max;
	Integer_List walk_list, bike_list, drive_list, stop_list, link_list, loc_list;
	List_Array walk_link, bike_link;
	Connect_Dir_Array connect_dir;
	No_Turn_Array no_turn;
	List_Array access_list, parking_access, parking_egress, transit_access, transit_egress;
	Route_Stop_Array route_stop;
	Park_Ride_Array park_ride;
	
	Trip_End_Data trip_org, trip_des, walk_org;
	Trip_End_Array org_array, des_array, park_array;

	Path_Array link_path, node_path [MAX_PATHS+1];
	Path_Array loc_path [MAX_PATHS+1], board_path [MAX_PATHS], alight_path [MAX_PATHS];
	Path_Data *first_ptr, *last_ptr;

	void Data_Processing (void);
	void Read_Household (void);
	void Read_Activity (void);
	void Read_Trip (void);

	int  Walk_to_Vehicle (Vehicle_Data *veh_ptr);
	bool Destination_Parking (void);
	int  Parking_to_Activity (Trip_End_Data *org, Trip_End_Data *lot, Trip_End_Data *des);
	int  Best_Combination (void);
	int  Set_Drive_Error (void);
	int  Set_Transit_Error (void);

	int Drive_Plan (Access_Type type, Vehicle_Data *veh_ptr);
	int Drive_Path (Access_Type type, bool best_flag = true);
	int Node_Plan (Access_Type type);
	int Node_Path (Access_Type type, bool best_flag = true);
	int Transit_Plan (void);
	void Transit_Path (int board, int xfer);
	void Location_Access (int origin, int xfer);
	void Walk_Access (int anode, int xfer);
	int Park_Ride_Plan (Vehicle_Data *veh_ptr);
	int Park_Ride_Lots (void);
	int Park_Ride_Return (Vehicle_Data *veh_ptr);
	int Build_Transit_Legs (void);
	int Set_Leg_Trip_Ends (void);
	int Save_Transit_Legs (void);
	int Save_Plan (Trip_End_Data *org, Trip_End_Data *des, int mode = Plan_File::WALK_MODE, int mode_id = 1);
	int Magic_Move (int end_time, int type);

	void Update_Travel_Times (void);
};
#endif
