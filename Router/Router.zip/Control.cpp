//*********************************************************
//	Control.cpp - process the control parameters
//*********************************************************

#include "Router.hpp"

#include "Utility.hpp"
#include "Scanf.hpp"

//---------------------------------------------------------
//	Program_Control
//---------------------------------------------------------

void Router::Program_Control (void)
{
	int i, lvalue, *value;
	double dvalue, value_res;
	char *str_ptr, *value_text, buffer [FIELD_BUFFER];

	//---- select modes ----
	
	str_ptr = Get_Control_String (ROUTE_SELECTED_MODES);

	if (str_ptr != NULL) {
		memset (select_mode, '\0', sizeof (select_mode));
		int num = 0;

		while (str_ptr != NULL) {
			str_ptr = Get_Integer (str_ptr, &lvalue);

			if (lvalue < 0 || lvalue >= MAX_MODE) {
				Error ("Selected Mode %d is Out of Range (1..%d)", lvalue, MAX_MODE);
			}
			if (lvalue > 0) {
				select_mode [lvalue] = true;
				num++;
			}
		}
		if (num == 0) {
			Error ("No Modes were Selected for Processing");
		}
	} else {
		for (int i=0; i < MAX_MODE; i++) {
			select_mode [i] = true;
		}
	}

	//---- new mode ----
	
	str_ptr = Get_Control_String (ROUTE_WITH_SPECIFIED_MODE);

	if (str_ptr != NULL) {
		mode_flag = true;

		str_ptr = Get_Integer (str_ptr, &new_mode);

		if (new_mode < 1 || new_mode >= MAX_MODE) {
			Error ("Specified Mode %d is Out of Range (1..%d)", new_mode, MAX_MODE);
		}
	} else {
		mode_flag = false;
	}

	//---- check for drive modes ----

	drive_net = (mode_flag && (new_mode == DRIVE_ALONE || new_mode == PNR_OUT || 
		new_mode == PNR_IN || new_mode == CARPOOL2 || new_mode == CARPOOL3 || new_mode== CARPOOL4)) || 
		(!mode_flag && (select_mode [DRIVE_ALONE] || select_mode [PNR_OUT] || 
		select_mode [PNR_IN] || select_mode [CARPOOL2] || select_mode [CARPOOL3] || select_mode [CARPOOL4]));

	//---- set flags ----

	if (!drive_net) {
		Demand_File_False (LINK_DELAY);
		Demand_File_False (VEHICLE);
	}

	//---- open network files ----

	Demand_Service::Program_Control ();

	//---- set network flags ----

	transit_net = Network_File_Flag (TRANSIT_STOP) && 
					Network_File_Flag (TRANSIT_ROUTE) && 
					Network_File_Flag (TRANSIT_SCHEDULE);

	if (!transit_net && mode_flag && (new_mode >= TRANSIT && new_mode <= PNR_IN)) {
		Error ("Transit Routing Requires a Transit Network");
	}
	if (transit_net && ((mode_flag && (new_mode < TRANSIT || new_mode > PNR_IN)) ||
		(!mode_flag && !(select_mode [TRANSIT] || select_mode [RAIL_TRANSIT] ||
		select_mode [PNR_OUT] || select_mode [PNR_IN])))) {
		transit_net = false;
	}
	if (!transit_net) {
		Network_File_False (TRANSIT_STOP);
		Network_File_False (TRANSIT_FARE);
		Network_File_False (TRANSIT_ROUTE);
		Network_File_False (TRANSIT_SCHEDULE);
	}

	if (drive_net) {
		if (Get_Control_String (LIMIT_PARKING_ACCESS) != NULL) {
			limit_access = Get_Control_Flag (LIMIT_PARKING_ACCESS);
		}
	}
	walk_net = !limit_access || transit_net || (mode_flag && new_mode == ALL_WALK) ||
		(!mode_flag && select_mode [ALL_WALK]);

	bike_net = (mode_flag && new_mode == BICYCLE) || (!mode_flag && select_mode [BICYCLE]);

	loc_net = walk_net || bike_net;

	if (transit_net && (select_mode [PNR_OUT] || (mode_flag && new_mode == PNR_OUT))) {
		park_ride_flag = true;
	}

	//---- check for a delay file ----

	if (drive_net) {
		delay_flag = Demand_File_Flag (LINK_DELAY);

		if (!delay_flag) {
			dir_array = (Dir_Array *) new TTime_Array ();

			ttime_data.Period_Size (time_period);
		} else {
			time_period = ttime_data.Period_Size ();
		}
		cap_factor = time_period / 3600.0;
	}

	//---- open the household list file ----
	
	str_ptr = Get_Control_String (HOUSEHOLD_LIST);

	if (str_ptr != NULL) {
		hhlist_file.File_Type ("Household List");
		Print (1);

		hhlist_file.Open (Project_Filename (str_ptr, Extension ()));
		hhlist_flag = true;
	}

	//---- check for a household file ----

	if (Demand_File_Flag (HOUSEHOLD)) {
		hhold_flag = true;

		//---- household type impedance ----

		str_ptr = Get_Control_String (HOUSEHOLD_TYPE_FIELD);

		if (str_ptr == NULL) goto control_error;

		//---- get the field numbers ----

		type_fld = Demand_Db_Base (HOUSEHOLD)->Field_Number (str_ptr);

		Print (2, "Household Type Field = %s", str_ptr);

		//---- get the range breaks ----

		str_ptr = Get_Control_String (HOUSEHOLD_TYPE_BREAK_POINTS);

		if (str_ptr == NULL) goto control_error;

		if (!hhold_range.Add_Breaks (str_ptr)) {
			Error ("Household Type Break Points = %s", str_ptr);
		}
		Print (1, "Household Type Break Points = %s", str_ptr);

		lvalue = hhold_range.Num_Ranges ();

		if (lvalue == 0) {
			Error ("Household Break Points were Not Defined");
		}
		if (lvalue == 1) {
			Write (1, "Warning: Household Break Points have No Affect");
			Demand_File_False (HOUSEHOLD);
		}
	} else {
		lvalue = 1;
	}

	//---- allocate space for value data ----

	if (!walk_value.Num_Records (lvalue) || !bike_value.Num_Records (lvalue) ||
		!wait_value.Num_Records (lvalue) || !xfer_value.Num_Records (lvalue) ||
		!time_value.Num_Records (lvalue) || !distance_value.Num_Records (lvalue) ||
		!cost_value.Num_Records (lvalue) || !walk_max.Num_Records (lvalue) ||
		!bike_max.Num_Records (lvalue) || !wait_max.Num_Records (lvalue) ||
		!xfer_max.Num_Records (lvalue) || !imped_xfer.Num_Records (lvalue) ||
		!path_max.Num_Records (lvalue) || !bias_rail.Num_Records (lvalue) ||
		!parkride_max.Num_Records (lvalue)) {

		Error ("Insufficient Memory for %d Household Break Values", lvalue);
	}

	//---- open the trip file ----

	str_ptr = Get_Control_String (TRIP_FILE);

	if (str_ptr != NULL) {
		Print (1);
		trip_file.Open (Project_Filename (str_ptr));
		trip_flag = true;

	} else {

		//---- open the activity file ----	

		str_ptr = Get_Control_String (ACTIVITY_FILE);

		if (str_ptr == NULL) goto control_error;

		activity_file.File_Type ("Activity File");

		Print (1);
		activity_file.Open (Project_Filename (str_ptr));
	}

	//---- get the time of day format ----
	
	str_ptr = Get_Control_String (TIME_OF_DAY_FORMAT);

	if (str_ptr == NULL) {
		str_ptr = "HOURS";
	}
	if (!trip_time.Format (str_ptr)) {
		Error ("Time of Day Format %s was Unrecognized", str_ptr);
	}
	Print (1, "Time of Day Format = %s", str_ptr);

	//---- open the plan file ----

	str_ptr = Get_Control_String (PLAN_FILE);

	if (str_ptr != NULL) {
		plan_file.Filename (Project_Filename (str_ptr, Extension ()));
		Print (1);

		str_ptr = Get_Control_String (PLAN_FORMAT);

		if (str_ptr != NULL) {
			plan_file.File_Format (str_ptr);
		}
		plan_file.Create ();
		save_plans = true;

		if (plan_file.Record_Format () == BINARY) {
			Print (1, "%s Format = BINARY", plan_file.File_Type ());
		}

		//---- node list paths ----
		
		if (Get_Control_String (NODE_LIST_PATHS) != NULL) {
			node_flag = Get_Control_Flag (NODE_LIST_PATHS);
		}
		if (node_flag) {
			Print (1, "Plan File will contain Node List Paths");
		} else {
			Print (1, "Plan File will contain Link List Paths");
		}
	}

	//---- select modes ----
	
	str_ptr = Get_Control_String (ROUTE_SELECTED_MODES);

	if (str_ptr != NULL) {
		Print (2, "Routes will be constructed for Selected Modes = %s", str_ptr);
	}

	//---- new mode ----

	if (mode_flag) {
		Print (2, "Route with Specified Mode = %d", new_mode);
	}
	Print (1);

	//---- limit parking access ----

	if (drive_net) {
		if (limit_access) {
			Print (1, "Access to Parking Lots will be Limited to Process Links");
		} else {
			Print (1, "Access to Parking Lots can include Walk Trips");
		}
	}
	
	//---- write walk path ----

	if (walk_net) {
		walk_detail = Get_Control_Flag (WALK_PATH_DETAILS);

		if (walk_detail) {
			Print (1, "Walk Path Details will be written to the Plan File");
		} else {
			Print (1, "Walk Path Details will Not be written to the Plan File");
		}
	}

	//---- ignore time constraints ----
	
	ignore_time = Get_Control_Flag (IGNORE_TIME_CONSTRAINTS);

	if (ignore_time) {
		Print (1, "Activity Schedule Constraints will be Ignored");
	} else {
		Print (1, "Activity Schedule Constraints will be Considered");
	}

	//---- ignore routing errors ----
	
	ignore_errors = Get_Control_Flag (IGNORE_ROUTING_PROBLEMS);

	if (ignore_errors) {
		Print (1, "Routing Errors will be Replaced by Magic Moves");
	} else {
		Print (1, "Routing Errors will Terminate Plan Construction");
	}

	//---- random impedance ----
	
	str_ptr = Get_Control_String (PERCENT_RANDOM_IMPEDANCE);

	if (str_ptr != NULL) {
		random_imped = atoi (str_ptr);

		if (random_imped < 0 || random_imped > 100) {
			Error ("Percent Random Impedance %d is Out of Range (0..100)", random_imped);
		}
	}
	if (random_imped == 0) {
		random_flag = false;

		Print (2, "Random Impedance Adjustments are Disabled");

	} else {
		random_flag = true;

		Print (2, "Percent Random Impedance = %d", random_imped);

		//---- random number seed ----

		str_ptr = Get_Control_String (RANDOM_NUMBER_SEED);

		if (str_ptr != NULL) {
			random.Seed (atoi (str_ptr));
		}
		Print (1, "Random Number Seed = %d", random.Seed ());
	}

	//---- walk speed ----
	
	str_ptr = Get_Control_String (WALK_SPEED);

	if (str_ptr != NULL) {
		walk_speed = atof (str_ptr);

		if (walk_speed < 0.5 || walk_speed > 10.0) {
			Error ("Walk Speed %.1lf is Out of Range (0.5..10)", walk_speed);
		}
	}
	Print (2, "Walk Speed = %.2lf meters per second", walk_speed);

	//---- bicycle speed ----
	
	if (bike_net) {
		str_ptr = Get_Control_String (BICYCLE_SPEED);

		if (str_ptr != NULL) {
			bike_speed = atof (str_ptr);

			if (bike_speed < 1.0 || bike_speed > 20.0) {
				Error ("Bicycle Speed %.1lf is Out of Range (1..20)", bike_speed);
			}
		}
		Print (1, "Bicycle Speed = %.2lf meters per second", bike_speed);
	}

	//---- impedance value processing ----

	value_res = (1 << value_roll);
	value_text = (char *) ((hhold_flag) ? "s " : " ");

	//---- walk time value ----
	
	str_ptr = Get_Control_String (WALK_TIME_VALUE);

	Print (2, "Walk Time Value%s=", value_text);
	dvalue = value_walk;

	for (i=1; (value = walk_value.Record (i)) != NULL; i++) {
		if (str_ptr != NULL) {
			str_ptr = Get_Double (str_ptr, &dvalue);

			if (dvalue < 0.0 || dvalue > 1000.0) {
				Error ("Walk Time Value %.1lf is Out of Range (0..1000)", dvalue);
			}
		}
		Print (0, " %.2lf ", dvalue);

		*value = (int) (dvalue * value_res + 0.5);
	}
	Print (0, "impedance units per second");

	//---- bicycle time value ----

	if (bike_net) {
		str_ptr = Get_Control_String (BICYCLE_TIME_VALUE);

		Print (1, "Bicycle Time Value%s=", value_text);
		dvalue = value_bike;

		for (i=1; (value = bike_value.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Double (str_ptr, &dvalue);

				if (dvalue < 0.0 || dvalue > 1000.0) {
					Error ("Bicycle Time Value %.1lf is Out of Range (0..1000)", dvalue);
				}
			}
			Print (0, " %.2lf ", dvalue);

			*value = (int) (dvalue * value_res + 0.5);
		}
		Print (0, "impedance units per second");
	}

	if (transit_net) {

		//---- first wait value ----
		
		str_ptr = Get_Control_String (FIRST_WAIT_VALUE);

		Print (1, "First Wait Time Value%s=", value_text);
		dvalue = value_wait;

		for (i=1; (value = wait_value.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Double (str_ptr, &dvalue);

				if (dvalue < 0.0 || dvalue > 1000.0) {
					Error ("First Wait Value %.1lf is Out of Range (0..1000)", dvalue);
				}
			}
			Print (0, " %.2lf ", dvalue);

			*value = (int) (dvalue * value_res + 0.5);
		}
		Print (0, "impedance units per second");

		//---- transfer wait value ----
		
		str_ptr = Get_Control_String (TRANSFER_WAIT_VALUE);

		Print (1, "Transfer Wait Time Value%s=", value_text);
		dvalue = value_xfer;

		for (i=1; (value = xfer_value.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Double (str_ptr, &dvalue);

				if (dvalue < 0.0 || dvalue > 1000.0) {
					Error ("Transfer Wait Value %.1lf is Out of Range (0..1000)", dvalue);
				}
			}
			Print (0, " %.2lf ", dvalue);

			*value = (int) (dvalue * value_res + 0.5);
		}
		Print (0, "impedance units per second");
	}

	//---- vehicle time value ----
	
	str_ptr = Get_Control_String (VEHICLE_TIME_VALUE);

	Print (1, "Vehicle Time Value%s=", value_text);
	dvalue = value_time;

	for (i=1; (value = time_value.Record (i)) != NULL; i++) {
		if (str_ptr != NULL) {
			str_ptr = Get_Double (str_ptr, &dvalue);

			if (dvalue < 0.0 || dvalue > 1000.0) {
				Error ("Vehicle Time Value %.1lf is Out of Range (0..1000)", dvalue);
			}
		}
		Print (0, " %.2lf ", dvalue);

		*value = (int) (dvalue * value_res + 0.5);
	}
	Print (0, "impedance units per second");

	//---- distance value ----
	
	str_ptr = Get_Control_String (DISTANCE_VALUE);

	Print (1, "Distance Value%s=", value_text);
	dvalue = value_distance;

	for (i=1; (value = distance_value.Record (i)) != NULL; i++) {
		if (str_ptr != NULL) {
			str_ptr = Get_Double (str_ptr, &dvalue);

			if (dvalue < 0.0 || dvalue > 1000.0) {
				Error ("Distance Value %.1lf is Out of Range (0..1000)", dvalue);
			}
		}
		Print (0, " %.2lf ", dvalue);

		*value = (int) (dvalue * value_res + 0.5);
	}
	Print (0, "impedance units per meter");

	//---- cost value ----
	
	str_ptr = Get_Control_String (COST_VALUE);

	Print (1, "Cost Value%s=", value_text);
	dvalue = value_cost;

	for (i=1; (value = cost_value.Record (i)) != NULL; i++) {
		if (str_ptr != NULL) {
			str_ptr = Get_Double (str_ptr, &dvalue);

			if (dvalue < 0.0 || dvalue > 1000.0) {
				Error ("Cost Value %.1lf is Out of Range (0..1000)", dvalue);
			}
		}
		Print (0, " %.2lf ", dvalue);

		*value = Round (dvalue * value_res);
	}
	Print (0, "impedance units per cent");

	//---- check the impedance values ----

	for (i=1; i <= time_value.Num_Records (); i++) {
		if (walk_value [i] == 0 && wait_value [i] == 0 && time_value [i] == 0 &&
			distance_value [i] == 0 && cost_value [i] == 0) {

			Error ("At least One Impedance Value must be Non-Zero for Household Type %d", i);
		}
	}

	if (transit_net) {
	
		//---- transfer_penalty ----
		
		str_ptr = Get_Control_String (TRANSFER_PENALTY);

		Print (1, "Transfer Penalt%s=", ((hhold_flag) ? "ies " : "y "));
		dvalue = xfer_imped;

		for (i=1; (value = xfer_value.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Double (str_ptr, &dvalue);

				if (dvalue < 0.0 || dvalue > 100000.0) {
					Error ("Transfer Penalty %.1lf is Out of Range (0..100000)", dvalue);
				}
			}
			Print (0, " %.2lf ", dvalue);

			*value = Round (dvalue * value_res);
		}
		Print (0, "impedance units per transfer");

		//---- rail bias factor ----
		
		str_ptr = Get_Control_String (RAIL_BIAS_FACTOR);

		Print (1, "Rail Bias Factor%s=", value_text);
		dvalue = rail_bias / 100.0;

		for (i=1; (value = cost_value.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Token (str_ptr, buffer);

				if (buffer [0] == 'N' || buffer [0] == 'n') {
					dvalue = 1.0;
				} else {
					dvalue = atof (buffer);
				}
				if (dvalue < 0.1 || dvalue > 1.0) {
					Error ("Rail Bias Factor %.2lf is Out of Range (0.1..1.0)", dvalue);
				}
			}
			if (dvalue == 1.0) {
				Print (0, " N/A ");
			} else {
				Print (0, " %.2lf ", dvalue);
			}
			*value = (int) (dvalue * 100.0 + 0.5);
		}
		Print (0, "impedance factor");
	}

	//---- max walk distance ----
	
	str_ptr = Get_Control_String (MAX_WALK_DISTANCE);

	Print (2, "Maximum Walk Distance%s=", value_text);
	lvalue = max_walk;

	for (i=1; (value = walk_max.Record (i)) != NULL; i++) {
		if (str_ptr != NULL) {
			str_ptr = Get_Token (str_ptr, buffer);

			if (buffer [0] == 'N' || buffer [0] == 'n') {
				lvalue = 0;
			} else {
				lvalue = atoi (buffer);
			}
			if (lvalue != 0 && (lvalue < 100 || lvalue > 10000)) {
				Error ("Maximum Walk Distance %d is Out of Range (100..10000)", lvalue);
			}
		}
		if (lvalue == 0) {
			Print (0, " N/A ");
		} else {
			Print (0, " %d ", lvalue);
		}
		*value = Round (lvalue / walk_speed);
	}
	Print (0, "meters");

	//---- max bike distance ----
	
	if (bike_net) {
		str_ptr = Get_Control_String (MAX_BICYCLE_DISTANCE);

		Print (1, "Maximum Bicycle Distance%s=", value_text);
		lvalue = max_bike;

		for (i=1; (value = bike_max.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Token (str_ptr, buffer);

				if (buffer [0] == 'N' || buffer [0] == 'n') {
					lvalue = 0;
				} else {
					lvalue = atoi (buffer);
				}
				if (lvalue != 0 && (lvalue < 1000 || lvalue > 20000)) {
					Error ("Maximum Bicycle Distance %d is Out of Range (1000..20000)", lvalue);
				}
			}
			if (lvalue == 0) {
				Print (0, " N/A ");
			} else {
				Print (0, " %d ", lvalue);
			}
			*value = Round (lvalue / bike_speed);
		}
		Print (0, "meters");
	}

	if (transit_net) {

		//---- max wait time ----

		str_ptr = Get_Control_String (MAX_WAIT_TIME);

		Print (1, "Maximum Waiting Time%s=", value_text);
		lvalue = max_wait;

		for (i=1; (value = wait_max.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Token (str_ptr, buffer);

				if (buffer [0] == 'N' || buffer [0] == 'n') {
					lvalue = 0;
				} else {
					lvalue = atoi (buffer);
				}
				if (lvalue != 0 && (lvalue < 5 || lvalue > 200)) {
					Error ("Maximum Waiting Time %d is Out of Range (5..200)", lvalue);
				}
			}
			if (lvalue == 0) {
				Print (0, " N/A ");
			} else {
				Print (0, " %d ", lvalue);
			}
			*value = Round (lvalue * 60);
		}
		Print (0, "minutes");

		//---- max transfers ----

		str_ptr = Get_Control_String (MAX_NUMBER_OF_TRANSFERS);

		Print (1, "Maximum Number of Transfers =");
		lvalue = max_transfers;

		for (i=1; (value = xfer_max.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Token (str_ptr, buffer);

				if (buffer [0] == 'N' || buffer [0] == 'n') {
					lvalue = 100;
				} else {
					lvalue = atoi (buffer);
				}
				if (lvalue != 100 && (lvalue < 0 || lvalue > 10)) {
					Error ("Maximum Number of Transfers %d is Out of Range (0..10)", lvalue);
				}
			}
			if (lvalue == 100) {
				Print (0, " N/A ");
			} else {
				Print (0, " %d ", lvalue);
			}
			*value = lvalue;
		}

		//---- max paths ----
		
		str_ptr = Get_Control_String (MAX_NUMBER_OF_PATHS);

		Print (1, "Maximum Number of Paths =");
		lvalue = max_paths;
		max_paths = 0;

		for (i=1; (value = path_max.Record (i)) != NULL; i++) {
			if (str_ptr != NULL) {
				str_ptr = Get_Token (str_ptr, buffer);

				if (buffer [0] == 'N' || buffer [0] == 'n') {
					lvalue = 0;
				} else {
					lvalue = atoi (buffer);
				}
				if (lvalue != 0 && (lvalue < 1 || lvalue > MAX_PATHS)) {
					Error ("Maximum Number of Paths %d is Out of Range (1..%d)", lvalue, MAX_PATHS);
				}
			}
			if (lvalue == 0) {
				Print (0, " N/A ");
			} else {
				Print (0, " %d ", lvalue);
			}
			if (lvalue == 0 || lvalue > xfer_max [i] + 1) {
				*value = xfer_max [i] + 1;
			} else {
                *value = lvalue;
			}
			if (*value > max_paths) max_paths = *value;
		}

		//---- max park ride percentage ----

		if (park_ride_flag) {
			str_ptr = Get_Control_String (MAX_PARK_RIDE_PERCENTAGE);

			Print (1, "Maximum Park-&-Ride Percentage%s=", value_text);
			lvalue = max_parkride;

			for (i=1; (value = parkride_max.Record (i)) != NULL; i++) {
				if (str_ptr != NULL) {
					str_ptr = Get_Token (str_ptr, buffer);

					if (buffer [0] == 'N' || buffer [0] == 'n') {
						lvalue = 0;
					} else {
						lvalue = atoi (buffer);
					}
					if (lvalue != 0 && (lvalue < 1 || lvalue > 100)) {
						Error ("Maximum Park-&-Ride Percentage %d is Out of Range (1..100)", lvalue);
					}
				}
				if (lvalue == 0) {
					Print (0, " N/A ");
				} else {
					Print (0, " %d ", lvalue);
				}
				*value = (lvalue != 0) ? lvalue : 100;
			}
		}

		//---- max legs per path ----

		str_ptr = Get_Control_String (MAX_LEGS_PER_PATH);

		if (str_ptr != NULL) {
			leg_check = atoi (str_ptr);

			if (leg_check < 10 || leg_check > 10000) {
				Error ("Maximum Legs Per Path %d is Out of Range (10..10000)", leg_check);
			}
			Print (1, "Maximum Legs Per Path = %d", leg_check);
		}
	}

	value_walk = (int) (dvalue * value_res + 0.5);
	value_bike = (int) (dvalue * value_res + 0.5);
	value_wait = (int) (dvalue * value_res + 0.5);
	value_xfer = (int) (dvalue * value_res + 0.5);
	value_time = (int) (dvalue * value_res + 0.5);
	value_distance = (int) (dvalue * value_res + 0.5);
	value_cost = Round (dvalue * value_res);
	xfer_imped = (Round (dvalue * value_res) + value_round) >> value_roll;
	rail_bias = (int) (dvalue * 100.0 + 0.5);
	bias_flag = (rail_bias != 100);
	walk_flag = (max_walk != 0);
	bike_flag = (max_bike != 0);
	wait_flag = (max_wait != 0);

	//---- max circuity ratio ----

	if (drive_net) {
		
		str_ptr = Get_Control_String (MAX_CIRCUITY_RATIO);

		if (str_ptr != NULL) {
			Get_Double (str_ptr, &dvalue);

			if (dvalue == 0.0) {
				Print (2, "Path Circuity Tests are Disabled");
			} else {
				if (dvalue < 1.0 || dvalue > 10.0) {
					Error ("Maximum Circuity Ratio %.0lf is Out of Range (1..10)", dvalue);
				}
				max_ratio = (int) (dvalue * 100.0 + 0.5);
				distance_flag = true;
			}
		}
		if (distance_flag) {
			Print (2, "Maximum Circuity Ratio = %.2lf", max_ratio / 100.0);
			max_ratio -= 100;

			//---- min circuity distance ----
			
			str_ptr = Get_Control_String (MIN_CIRCUITY_DISTANCE);

			if (str_ptr != NULL) {
				Get_Integer (str_ptr, &min_distance);

				if (min_distance < 0 || min_distance > 10000) {
					Error ("Minimum Circuity Distance %d is Out of Range (0..10000)", min_distance);
				}
			}
			Print (1, "Minimum Circuity Distance = %d meters", min_distance);

			//---- max circuity distance ----
			
			str_ptr = Get_Control_String (MAX_CIRCUITY_DISTANCE);

			if (str_ptr != NULL) {
				Get_Integer (str_ptr, &max_distance);

				if (max_distance < min_distance || max_distance > 100000) {
					Error ("Maximum Circuity Distance %d is Out of Range (%d..100000)", max_distance, min_distance);
				}
			}
			Print (1, "Maximum Circuity Distance = %d meters", max_distance);
			min_distance = Round (min_distance);
			max_distance = Round (max_distance);
		}
	}

	//---- max link delay errors ----
	
	if (delay_flag) {
		str_ptr = Get_Control_String (MAX_LINK_DELAY_ERRORS);

		if (str_ptr != NULL) {
			Get_Integer (str_ptr, &max_delay_errors);

			if (max_delay_errors < 0) {
				Error ("Maximum Link Delay Errors %d is Out of Range", max_delay_errors);
			}
		}
		if (max_delay_errors > 0) {
			if (Max_Problems () == 0) Print (1);
			Print (1, "Maximum Number of Link Delay Errors = %d", max_delay_errors);
		}
	}

	//---- link delay updates ----
	
	str_ptr = Get_Control_String (LINK_DELAY_UPDATE_RATE);

	if (str_ptr != NULL) {
		Get_Integer (str_ptr, &update_rate);

		if (update_rate < 0 || update_rate > 5000) {
			Error ("Link Delay Update Rate %d is Out of Range (0..5000)", update_rate);
		}
		if (update_rate > 0) update_flag = true;
	}
	if (!update_flag) {
		Print (2, "Link Delay Updates are Disabled");
	} else {
		Print (2, "Link Delay Update Rate = %d trips", update_rate);
		Print (1);

		//---- equation parameters ----

		equation.Num_Equations (EXTERNAL);

		for (i=1; i <= EXTERNAL; i++) {
			str_ptr = Get_Control_String (EQUATION_PARAMETERS_x, i);

			equation.Add_Equation (i, str_ptr);
		}
	}

	//---- open the problem file ----
	
	str_ptr = Get_Control_String (PROBLEM_FILE);

	if (str_ptr != NULL) {
		problem_file.Filename (Project_Filename (str_ptr, Extension ()));
		Print (1);

		str_ptr = Get_Control_String (PROBLEM_FORMAT);

		if (str_ptr != NULL) {
			problem_file.Dbase_Format (str_ptr);
		}
		problem_file.Create ();
		problem_flag = true;

		problem_file.Create_Fields ();
		problem_file.Write_Header ();
	}

	//---- max routing problems ----
	
	str_ptr = Get_Control_String (MAX_ROUTING_PROBLEMS);

	if (str_ptr != NULL) {
		Get_Integer (str_ptr, &lvalue);

		if (lvalue < 0) {
			Error ("Maximum Routing Problems %d is Out of Range", lvalue);
		}
		Max_Problems (lvalue);
	}
	if (Max_Problems () > 0) {
		Print (1, "Maximum Number of Routing Problems = %d", Max_Problems ());
	}

	tod_flag = delay_flag || update_flag;

	//---- set default parameters ----

	if (!hhold_flag) {
		value_walk = walk_value [1];
		value_bike = bike_value [1];
		value_time = time_value [1];
		value_wait = wait_value [1];
		value_xfer = xfer_value [1];
		value_distance = distance_value [1];
		value_cost = cost_value [1];
		xfer_imped = imped_xfer [1];
		rail_bias = bias_rail [1];
        max_walk = walk_max [1];
		max_bike = bike_max [1];
		max_wait = wait_max [1];
		max_transfers = xfer_max [1];
		max_paths = path_max [1];
		max_parkride = parkride_max [1];

		walk_flag = (max_walk != 0);
		bike_flag = (max_bike != 0);
		wait_flag = (max_wait != 0);
		bias_flag = (rail_bias != 100);
	}
	return;

control_error:
	Error ("Missing Control Key = %s", Current_Key ());
}
