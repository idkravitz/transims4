//*********************************************************
//	Vehicle_Process.cpp - Read the Vehicle File
//*********************************************************

#include "Router.hpp"

#include "Vehicle_File.hpp"

//---------------------------------------------------------
//	Vehicle_Processing
//---------------------------------------------------------

bool Router::Vehicle_Processing (Db_File *fh)
{
	if (First_Record ()) {
		int nveh;

		//---- reserve memory ----
			
		if (hhlist_flag) {
			nveh = household_data.Num_Records ();
		} else {
			Vehicle_File *file = (Vehicle_File *) fh;

			nveh = file->Estimate_Records ();
		}
		if (!vehicle_data.Max_Records (nveh)) {
			Error ("Insufficient Memory for %d Vehicle Records", nveh);
		}
	}

	if (Demand_Service::Vehicle_Processing (fh)) {

		Vehicle_Data *vehicle_ptr = vehicle_data.New_Record ();

		if (hhlist_flag) {
			int hhold = vehicle_ptr->Household ();

			if (household_data.Get (hhold) == NULL) return (false);
		}		
		vehicle_ptr->Type (Veh_Type_Code (vehicle_ptr->Type ()));

		return (true);
	}
	return (false);
}
