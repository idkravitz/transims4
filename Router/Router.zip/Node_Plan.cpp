//*********************************************************
//	Node_Plan.cpp - Build a Node-based Plan
//*********************************************************

#include "Router.hpp"

//---------------------------------------------------------
//	Node_Plan
//---------------------------------------------------------

int Router::Node_Plan (Access_Type type)
{
	Link_Data *link_ptr;

	if (trip_org.ID () == trip_des.ID ()) return (0);

	//---- check the origin link ----

	link_ptr = link_data [trip_org.Link ()];
		
	if (!Access_Permission (link_ptr->Access (), type)) {
		return (Set_Problem (LINK_PROBLEM));
	}

	//---- check the destination link ----

	link_ptr = link_data [trip_des.Link ()];

	if (!Access_Permission (link_ptr->Access (), type)) {
		return (Set_Problem (LINK_PROBLEM));
	}

	//---- initialize the path data ----

	//memset (node_path [0], '\0', node_path_size);

	org_array.Reset ();
	des_array.Reset ();

	org_array.Add (&trip_org);
	des_array.Add (&trip_des);

	//---- build the path between the origin and destination activity locations ----

	if (!Node_Path (type)) {
		if (length_flag) {
			return (Set_Problem ((type == WALK) ? WALK_PROBLEM : BIKE_PROBLEM));
		} else if (time_flag) {
			return (Set_Problem (TIME_PROBLEM));
		}
		return (Set_Problem (PATH_PROBLEM));
	}

	//---- save the plan record ----

	return (Save_Plan (&trip_org, des_array.First (), ((type == WALK) ? Plan_File::WALK_MODE : Plan_File::BIKE_MODE)));
}
