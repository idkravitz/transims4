//*********************************************************
//	Execute.cpp - main execution procedure
//*********************************************************

#include "Router.hpp"

//---------------------------------------------------------
//	Execute
//---------------------------------------------------------

void Router::Execute (void)
{
	//---- read the household list ----

	if (hhlist_flag || hhold_flag) {
		Read_Household ();
	}

	//---- read the network ----

	Demand_Service::Execute ();

	//---- prepare path building data ----

	Data_Processing ();

	//---- process each trip ----

	Break_Check (5);

	if (trip_flag) {
		Read_Trip ();

		Write (2, "Number of Trip Records = %d", nrecord);
		Write (1, "Number of Trips Processed = %d", nprocess);
	} else {
		Read_Activity ();

		Write (2, "Number of Activity Records = %d", nrecord);
		Write (1, "Number of Activities Processed = %d", nprocess);
	}
	Write (1, "Number of Households Processed = %d", nhh_proc);
	Write (1, "Number of Vehicle Trips Saved = %d", ntrips);

	if (update_flag) {
		Write (1, "Number of Travel Time Updates = %d", nupdates);
	}

	Break_Check (5);

	Write (2, "Number of Output Plans = %d", plan_file.Num_Plans ());
	Write (1, "Number of Output Records = %d", plan_file.Num_Records ());
	Write (1, "Number of Output Travelers = %d", plan_file.Num_Travelers ());
	Write (1, "Number of Output Trips = %d", plan_file.Num_Trips ());

	if (ignore_errors) {
		Write (2, "Number of Trips Replaced by Magic Moves = %d", nmagic);
	}
	if (ntransit) {
		Write (2, "Number of Illogical Transit Adjustments = %d", ntransit);
	}
	
	//---- print the error report ----

	Report_Problems ();

	//Pause_Process ();

	Exit_Stat (DONE);
}
