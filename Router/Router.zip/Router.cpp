//*********************************************************
//	Router.cpp - Network Path Builder
//*********************************************************

#include "Router.hpp"

char * Router::HOUSEHOLD_LIST					= "HOUSEHOLD_LIST";
char * Router::TRIP_FILE						= "TRIP_FILE";
char * Router::ACTIVITY_FILE					= "ACTIVITY_FILE";
char * Router::TIME_OF_DAY_FORMAT				= "TIME_OF_DAY_FORMAT";
char * Router::PLAN_FILE						= "PLAN_FILE";
char * Router::PLAN_FORMAT						= "PLAN_FORMAT";
char * Router::NODE_LIST_PATHS					= "NODE_LIST_PATHS";
char * Router::ROUTE_SELECTED_MODES				= "ROUTE_SELECTED_MODES";
char * Router::ROUTE_WITH_SPECIFIED_MODE		= "ROUTE_WITH_SPECIFIED_MODE";
char * Router::LIMIT_PARKING_ACCESS				= "LIMIT_PARKING_ACCESS";
char * Router::WALK_PATH_DETAILS				= "WALK_PATH_DETAILS";
char * Router::IGNORE_TIME_CONSTRAINTS			= "IGNORE_TIME_CONSTRAINTS";
char * Router::IGNORE_ROUTING_PROBLEMS			= "IGNORE_ROUTING_PROBLEMS";
char * Router::PERCENT_RANDOM_IMPEDANCE			= "PERCENT_RANDOM_IMPEDANCE";
char * Router::RANDOM_NUMBER_SEED				= "RANDOM_NUMBER_SEED";
char * Router::HOUSEHOLD_TYPE_FIELD				= "HOUSEHOLD_TYPE_FIELD";
char * Router::HOUSEHOLD_TYPE_BREAK_POINTS		= "HOUSEHOLD_TYPE_BREAK_POINTS";
char * Router::WALK_SPEED						= "WALK_SPEED";
char * Router::BICYCLE_SPEED                    = "BICYCLE_SPEED";
char * Router::WALK_TIME_VALUE					= "WALK_TIME_VALUE";
char * Router::BICYCLE_TIME_VALUE				= "BICYCLE_TIME_VALUE";
char * Router::FIRST_WAIT_VALUE					= "FIRST_WAIT_VALUE";
char * Router::TRANSFER_WAIT_VALUE				= "TRANSFER_WAIT_VALUE";
char * Router::VEHICLE_TIME_VALUE				= "VEHICLE_TIME_VALUE";
char * Router::DISTANCE_VALUE					= "DISTANCE_VALUE";
char * Router::COST_VALUE						= "COST_VALUE";
char * Router::TRANSFER_PENALTY					= "TRANSFER_PENALTY";
char * Router::RAIL_BIAS_FACTOR					= "RAIL_BIAS_FACTOR";
char * Router::MAX_WALK_DISTANCE				= "MAX_WALK_DISTANCE";
char * Router::MAX_BICYCLE_DISTANCE				= "MAX_BICYCLE_DISTANCE";
char * Router::MAX_WAIT_TIME					= "MAX_WAIT_TIME";
char * Router::MAX_NUMBER_OF_TRANSFERS			= "MAX_NUMBER_OF_TRANSFERS";
char * Router::MAX_NUMBER_OF_PATHS				= "MAX_NUMBER_OF_PATHS";
char * Router::MAX_PARK_RIDE_PERCENTAGE			= "MAX_PARK_RIDE_PERCENTAGE";
char * Router::MAX_LEGS_PER_PATH				= "MAX_LEGS_PER_PATH";
char * Router::MAX_CIRCUITY_RATIO				= "MAX_CIRCUITY_RATIO";
char * Router::MIN_CIRCUITY_DISTANCE			= "MIN_CIRCUITY_DISTANCE";
char * Router::MAX_CIRCUITY_DISTANCE			= "MAX_CIRCUITY_DISTANCE";
char * Router::MAX_LINK_DELAY_ERRORS			= "MAX_LINK_DELAY_ERRORS";
char * Router::LINK_DELAY_UPDATE_RATE			= "LINK_DELAY_UPDATE_RATE";
char * Router::EQUATION_PARAMETERS_x			= "EQUATION_PARAMETERS_*";
char * Router::PROBLEM_FILE						= "PROBLEM_FILE";
char * Router::PROBLEM_FORMAT					= "PROBLEM_FORMAT";
char * Router::MAX_ROUTING_PROBLEMS				= "MAX_ROUTING_PROBLEMS";

//---------------------------------------------------------
//	Router constructor
//---------------------------------------------------------

Router::Router (void) : Demand_Service (), Problem_Service ()
{
	Program ("Router");
	Version ("4.0.10");
	Title ("Network Path Builder");

	Network_File required_network [] = {
		NODE, LINK, LANE_CONNECTIVITY, PARKING, ACTIVITY_LOCATION, PROCESS_LINK, END_NETWORK
	};

	Network_File optional_network [] = {
		DIRECTORY, LANE_USE, TURN_PROHIBITION, 
		TRANSIT_STOP, TRANSIT_FARE, TRANSIT_ROUTE, TRANSIT_SCHEDULE, 
		END_NETWORK
	};

	Demand_File required_demand [] = {
		VEHICLE, END_DEMAND
	};
	Demand_File optional_demand [] = {
		HOUSEHOLD, LINK_DELAY, END_DEMAND
	};

	char *keys [] = {
		HOUSEHOLD_LIST,
		TRIP_FILE,
		ACTIVITY_FILE,
		TIME_OF_DAY_FORMAT,
		PLAN_FILE,
		PLAN_FORMAT,
		NODE_LIST_PATHS,
		ROUTE_SELECTED_MODES,
		ROUTE_WITH_SPECIFIED_MODE,
		LIMIT_PARKING_ACCESS,
		WALK_PATH_DETAILS,
		IGNORE_TIME_CONSTRAINTS,
		IGNORE_ROUTING_PROBLEMS,
		PERCENT_RANDOM_IMPEDANCE,
		RANDOM_NUMBER_SEED,
		HOUSEHOLD_TYPE_FIELD,
		HOUSEHOLD_TYPE_BREAK_POINTS,
		WALK_SPEED,
		BICYCLE_SPEED,
		WALK_TIME_VALUE,
		BICYCLE_TIME_VALUE,
		FIRST_WAIT_VALUE,
		TRANSFER_WAIT_VALUE,
		VEHICLE_TIME_VALUE,
		DISTANCE_VALUE,
		COST_VALUE,
		TRANSFER_PENALTY,
		RAIL_BIAS_FACTOR,
		MAX_WALK_DISTANCE,
		MAX_BICYCLE_DISTANCE,
		MAX_WAIT_TIME,
		MAX_NUMBER_OF_TRANSFERS,
		MAX_NUMBER_OF_PATHS,
		MAX_PARK_RIDE_PERCENTAGE,
		MAX_LEGS_PER_PATH,
		MAX_CIRCUITY_RATIO,
		MIN_CIRCUITY_DISTANCE,
		MAX_CIRCUITY_DISTANCE,
		MAX_LINK_DELAY_ERRORS,
		LINK_DELAY_UPDATE_RATE,
		EQUATION_PARAMETERS_x,
		PROBLEM_FILE,
		PROBLEM_FORMAT,
		MAX_ROUTING_PROBLEMS,
		NULL
	};

	Required_Network_Files (required_network);
	Optional_Network_Files (optional_network);
	Required_Demand_Files (required_demand);
	Optional_Demand_Files (optional_demand);

	Key_List (keys);

	Check_Data (true);
	Renumber (true);
	Max_Problems (100000);

	nhh_list = nhh_proc = nrecord = nprocess = ntrips = num_trips = update_rate = nupdates = 0;
	random_imped = max_tod = new_mode = nmagic = ntransit = nroute = 0;

	limit_access = node_flag = true;
	walk_net = bike_net = drive_net = loc_net = transit_net = fare_flag = false;
	hhlist_flag = hhold_flag = trip_flag = ignore_time = update_flag = tod_flag = false;
	random_flag = walk_flag = bike_flag = walk_detail = walk_active = false;
	save_plans = problem_flag = ignore_errors = delay_flag = zero_flag = false;
	mode_flag = park_ride_flag = distance_flag = wait_flag = false;
	time_flag = dist_flag = length_flag = wait_time_flag = access_flag = bias_flag = false;

	first_ptr = last_ptr = NULL;

	type_fld = 0;

	walk_speed = 1.0;
	bike_speed = 4.0;

	value_walk = 20;
	value_bike = 15;
	value_wait = 20;
	value_xfer = 20;
	value_time = 10;
	value_distance = 0;
	value_cost = 1;

	value_roll = 3;		//---- 1/8 resolution ----
	value_round = (1 << (value_roll-1));

	offset_roll = 11;	//---- 1/2048 resolution ----
	offset_round = (1 << (offset_roll-1));
	
	time_period = 900;		//---- 15 minutes ----

	max_walk = 2000;
	max_bike = 10000;
	max_wait = 60;
	max_transfers = 3;
	max_paths = 4;
	max_parkride = 50;
	rail_bias = 100;
	xfer_imped = 0;

	cap_factor = 0.25;

	max_delay_errors = 100000;

	leg_check = 1000;
	min_distance = 2000;
	max_distance = 20000;
	max_ratio = 200;
}

//---------------------------------------------------------
//	Router destructor
//---------------------------------------------------------

Router::~Router (void)
{
}

//---------------------------------------------------------
//	main program
//---------------------------------------------------------

int main (int commands, char *control [])
{
	Router *exe = new Router ();

	return (exe->Start_Execution (commands, control));
}
