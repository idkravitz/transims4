//*********************************************************
//	Data_Processing.cpp - data processing classes
//*********************************************************

#include "Router.hpp"

//---------------------------------------------------------
//	Data_Processing
//---------------------------------------------------------

void Router::Data_Processing (void)
{
	int record, *list, nstop, nparking, nlocation, naccess;

	int nnode = node_data.Num_Records ();
	int nlink = link_data.Num_Records ();
	int ndir = ttime_data.Num_Records ();

	//---- prepare data for drive paths ----

	if (walk_net || bike_net || drive_net) {
		int dir;
		int nwalk = 0;
		int nbike = 0;
		int ndrive = 0;

		Link_Data *link_ptr;
		TTime_Data *ttime_ptr;
		List_Data *walk_ptr, *bike_ptr;

		bool cap_update = (update_flag && cap_factor != 1.0);

		//---- initialize network data ----

		if (walk_net) {
			if (!walk_list.Num_Records (nnode) || !walk_link.Num_Records (nlink)) {
				Error ("Insufficient Memory for Walk Data");
			}
		}
		if (bike_net) {
			if (!bike_list.Num_Records (nnode) || !bike_link.Num_Records (nlink)) {
				Error ("Insufficient Memory for Bike Data");
			}
		}
		if (drive_net) {
			if (tod_flag) {
				int nperiod = ttime_data.Periods ();
				ttime_data.Period_Size (Round (ttime_data.Period_Size ()));
				ttime_data.Periods (nperiod);
			}
		}

		//---- process each link ----

		for (link_ptr = link_data.First (); link_ptr != NULL; link_ptr = link_data.Next ()) {
			record = link_data.Record_Index ();

			if (walk_net && Access_Permission (link_ptr->Access (), WALK)) {
				walk_ptr = walk_link [record];
				nwalk++;

				//---- add to the link lists ----

				list = walk_list.Record (link_ptr->Anode ());

				walk_ptr->From_List (*list);
				*list = record;

				list = walk_list.Record (link_ptr->Bnode ());

				walk_ptr->To_List (*list);
				*list = record;
			}

			if (bike_net && Access_Permission (link_ptr->Access (), BIKE)) {
				bike_ptr = bike_link [record];
				nbike++;

				//---- add to the link lists ----

				list = bike_list.Record (link_ptr->Anode ());

				bike_ptr->From_List (*list);
				*list = record;

				list = bike_list.Record (link_ptr->Bnode ());

				bike_ptr->To_List (*list);
				*list = record;
			}

			if (drive_net && (Access_Permission (link_ptr->Access (), CAR) || 
				Access_Permission (link_ptr->Access (), TRUCK) ||
				Access_Permission (link_ptr->Access (), SOV) ||
				Access_Permission (link_ptr->Access (), HOV2) ||
				Access_Permission (link_ptr->Access (), HOV3) ||
				Access_Permission (link_ptr->Access (), HOV4) ||
				Access_Permission (link_ptr->Access (), LIGHTTRUCK) ||
				Access_Permission (link_ptr->Access (), HEAVYTRUCK))) {

				//---- process A->B direction ----

				dir = link_ptr->AB_Dir ();

				if (dir >  0) {
					ndrive++;

					if (tod_flag) {
						ttime_ptr = ttime_data [dir];
						if (ttime_ptr == NULL) goto dir_error;

						int nperiod = ttime_ptr->Periods ();

						if (nperiod == 0) {
							nperiod = ttime_data.Periods ();

							if (!ttime_ptr->Periods (nperiod)) goto mem_error;
						}
						if (!delay_flag) {
							for (int i=1; i <= nperiod; i++) {
								ttime_ptr->TTime (i, ttime_ptr->Time0 ());
							}
						}
						if (cap_update) {
							ttime_ptr->Capacity ((int) (ttime_ptr->Capacity () * cap_factor + 0.5));
						}
					}
				}

				//---- process B->A direction ----

				dir = link_ptr->BA_Dir ();

				if (dir > 0) {
					ndrive++;
					if (tod_flag) {
						ttime_ptr = ttime_data [dir];
						if (ttime_ptr == NULL) goto dir_error;

						int nperiod = ttime_ptr->Periods ();

						if (nperiod == 0) {
							nperiod = ttime_data.Periods ();

							if (!ttime_ptr->Periods (nperiod)) goto mem_error;
						}
						if (!delay_flag) {
							for (int i=1; i <= nperiod; i++) {
								ttime_ptr->TTime (i, ttime_ptr->Time0 ());
							}
						}
						if (cap_update) {
							ttime_ptr->Capacity ((int) (ttime_ptr->Capacity () * cap_factor + 0.5));
						}
					}
				}
			} else {
				link_ptr->AB_Dir (0);
				link_ptr->BA_Dir (0);
			}
		}
		if (walk_net || bike_net || drive_net) {
			Break_Check (4);
			Print (1);
		}
		if (walk_net) {
			Print (1, "Number of Links in the Walk Network = %d", nwalk);
		}
		if (bike_net) {
			Print (1, "Number of Links in the Bicycle Network = %d", nbike);
		}
		if (drive_net) {
			Print (1, "Number of Directional Links in the Highway Network = %d", ndrive);
		}
	}

	//---- construct the approach-departure list ----

	if (drive_net) {
		int from_dir, to_dir;
		Connect_Data *connect_ptr;
		Connect_Dir_Data *list_ptr;
		Link_Data *link_ptr;

        int nconnect = connect_data.Num_Records ();

		if (!drive_list.Num_Records (ndir) || 
			!connect_dir.Num_Records (nconnect)) {
			Error ("Insufficient Memory for Link Connection Data");
		}

		//---- process each connection ----

		nconnect = 0;

		for (connect_ptr = connect_data.First (); connect_ptr != NULL; connect_ptr = connect_data.Next ()) {

			//---- convert the id code to dir index ----

			link_ptr = link_data [connect_ptr->In_Link ()];
			from_dir = (connect_ptr->In_Dir () == 0) ? link_ptr->AB_Dir () : link_ptr->BA_Dir ();

			if (from_dir == 0) continue;

			link_ptr = link_data [connect_ptr->Out_Link ()];
			to_dir = (connect_ptr->Out_Dir () == 0) ? link_ptr->AB_Dir () : link_ptr->BA_Dir ();

			if (to_dir == 0) continue;

			//---- add to the connection lists ----

			list = drive_list.Record (from_dir);
			list_ptr = connect_dir [++nconnect];

			list_ptr->List (*list);
			list_ptr->Dir (to_dir);
			*list = nconnect;
		}
		connect_dir.Max_Records (nconnect);

		Print (2, "Number of Highway Link Connections = %d", nconnect);

		connect_data.Clear ();

		//---- process turn prohibitions ----

		nconnect = turn_data.Num_Records ();

		if (nconnect > 0) {
			Turn_Data *turn_ptr;
			No_Turn_Data *no_turn_ptr;

			if (!no_turn.Num_Records (nconnect)) {
				Error ("Insufficient Memory for Turn Prohibition Data");
			}

			//---- process each turn prohibition ----

			nconnect = 0;

			for (turn_ptr = turn_data.First (); turn_ptr != NULL; turn_ptr = turn_data.Next ()) {

				//---- convert the id code to dir index ----

				link_ptr = link_data [turn_ptr->In_Link ()];
				from_dir = (turn_ptr->In_Dir () == 0) ? link_ptr->AB_Dir () : link_ptr->BA_Dir ();

				if (from_dir == 0) continue;

				link_ptr = link_data [turn_ptr->Out_Link ()];
				to_dir = (turn_ptr->Out_Dir () == 0) ? link_ptr->AB_Dir () : link_ptr->BA_Dir ();

				if (to_dir == 0) continue;

				//---- add to the connection lists ----

				for (record = drive_list [from_dir]; record; record = list_ptr->List ()) {

					list_ptr = connect_dir [record];

					if (list_ptr->Dir () == to_dir) {
						no_turn_ptr = no_turn [++nconnect];

						no_turn_ptr->TOD_List (list_ptr->TOD_List ());
						list_ptr->TOD_List (nconnect);

						no_turn_ptr->Start (turn_ptr->Start ());
						no_turn_ptr->Stop (turn_ptr->Stop ());
						break;
					}
				}
			}
			no_turn.Max_Records (nconnect);

			Print (2, "Number of Highway Turn Prohibitions = %d", nconnect);

			turn_data.Clear ();
		}
	}

	//---- build the access list ----

	naccess = access_data.Num_Records ();
	nlocation = location_data.Num_Records ();
	nparking = parking_data.Num_Records ();
	nstop = stop_data.Num_Records ();

	if (!access_list.Num_Records (naccess) ||
		!parking_access.Num_Records (nlocation) || !parking_egress.Num_Records (nparking) ||
		!transit_access.Num_Records (nlocation) || !transit_egress.Num_Records (nstop)) {
		Error ("Insufficient Memory for Access List Data");
	}

	Access_Data *access_ptr;
	List_Data *list_ptr, *acc_ptr;
	Location_Data *location_ptr;

	for (access_ptr = access_data.First (); access_ptr != NULL; access_ptr = access_data.Next ()) {
		record = access_data.Record_Index ();

		acc_ptr = access_list [record];

		//---- update the access lists ---

		if (access_ptr->From_Type () == LOCATION_ID) {
			if (access_ptr->To_Type () == PARKING_ID) {
				list_ptr = parking_access [access_ptr->From_ID ()];

				acc_ptr->From_List (list_ptr->From_List ());
				list_ptr->From_List (record);

				if (walk_net) {
					list_ptr = parking_egress [access_ptr->To_ID ()];

					acc_ptr->To_List (list_ptr->To_List ());
					list_ptr->To_List (record);
				}
			} else if (access_ptr->To_Type () == STOP_ID) {
				list_ptr = transit_access [access_ptr->From_ID ()];

				acc_ptr->From_List (list_ptr->From_List ());
				list_ptr->From_List (record);

				list_ptr = transit_egress [access_ptr->To_ID ()];

				acc_ptr->To_List (list_ptr->To_List ());
				list_ptr->To_List (record);

				//---- check walk access to transit ----

				location_ptr = location_data [access_ptr->From_ID ()];

				if (location_ptr->Link () == 0) {
					Write (1, "Warning: No Walk Access to Transit Stop %d through Activity Location %d", 
						stop_data [access_ptr->To_ID ()]->ID (), location_ptr->ID ());
				}
			}
			
		} else if (access_ptr->To_Type () == LOCATION_ID) {
			if (access_ptr->From_Type () == PARKING_ID) {
				list_ptr = parking_access [access_ptr->To_ID ()];

				acc_ptr->To_List (list_ptr->To_List ());
				list_ptr->To_List (record);

				if (walk_net) {
					list_ptr = parking_egress [access_ptr->From_ID ()];

					acc_ptr->From_List (list_ptr->From_List ());
					list_ptr->From_List (record);
				}
			} else if (access_ptr->From_Type () == STOP_ID) {
				list_ptr = transit_access [access_ptr->To_ID ()];

				acc_ptr->To_List (list_ptr->To_List ());
				list_ptr->To_List (record);

				list_ptr = transit_egress [access_ptr->From_ID ()];

				acc_ptr->From_List (list_ptr->From_List ());
				list_ptr->From_List (record);

				//---- check walk egress from transit ----

				location_ptr = location_data [access_ptr->To_ID ()];

				if (location_ptr->Link () == 0) {
					Write (1, "Warning: No Walk Access to Transit Stop %d through Activity Location %d", 
						stop_data [access_ptr->From_ID ()]->ID (), location_ptr->ID ());
				}
			}
		}
	}

	//---- build the route stop list ----

	if (transit_net) {
		int i, stop, *link;
		Route_Stop_Data rstop_rec;
		Line_Data *line_ptr;

		if (!link_list.Num_Records (nlink) || !loc_list.Num_Records (nlocation) ||
			!stop_list.Num_Records (nstop)) {
			Error ("Insufficient Memory for Transit Lists");
		}
		fare_flag = (Num_Fare_Zones () > 0);
		nroute = line_data.Num_Records () + 1;

		for (line_ptr = line_data.First (); line_ptr != NULL; line_ptr = line_data.Next ()) {
			rstop_rec.Route (line_data.Record_Index ());

			//if (line_ptr->Runs () == 0) {
			//	Error ("Route %d has not Scheduled Service", line_ptr->Route ());
			//}

			for (i=1; i <= line_ptr->Stops (); i++) {
				rstop_rec.Stop (i);

				stop = line_ptr->Stop (i);

				list = stop_list.Record (stop);

				rstop_rec.List (*list);

				if (!route_stop.Add (&rstop_rec)) {
					Error ("Adding Route-Stop data to the List");
				}
				*list = route_stop.Num_Records ();
			}
		}
		for (location_ptr = location_data.First (); location_ptr != NULL; location_ptr = location_data.Next ()) {
			record = location_data.Record_Index ();

			link = link_list.Record (location_ptr->Link ());
			list = loc_list.Record (record);

			*list = *link;
			*link = record;
		}

		//----- get the park-&-ride lots ----

		if (park_ride_flag) {
			Parking_Data *park_ptr;
			Link_Data *link_ptr;
			Node_Data *node_ptr;
			Park_Ride_Data park_rec;

			int ax, ay, bx, by;
			double factor;

			for (park_ptr = parking_data.First (); park_ptr != NULL; park_ptr = parking_data.Next ()) {
				if (park_ptr->Type () != PARKRIDE) continue;

				link_ptr = link_data [park_ptr->Link ()];

				node_ptr = node_data [link_ptr->Anode ()];

				ax = node_ptr->X ();
				ay = node_ptr->Y ();

				node_ptr = node_data [link_ptr->Bnode ()];

				bx = node_ptr->X ();
				by = node_ptr->Y ();

				factor = (double) park_ptr->Offset () / (double) link_ptr->Length ();

				park_rec.Parking (parking_data.Record_Index ());
				park_rec.X (ax + (int) ((bx - ax) * factor + 0.5));
				park_rec.Y (ay + (int) ((by - ay) * factor + 0.5));

				if (!park_ride.Add (&park_rec)) {
					Error ("Adding Park-&-Ride Lot to the List");
				}
			}
			Print (2, "Number of Park-&-Ride Lots = %d", park_ride.Num_Records ());
		}
	}

	//---- path building data ----

	plan_file.Check_Size (nnode + 1);

	if (drive_net) {
		if (!link_path.Num_Records (ndir)) goto path_error;
	}

	if (transit_net) {
		for (int i=0; i <= max_paths; i++) {
			if (!node_path [i].Num_Records (nnode)) goto path_error;
			if (!loc_path [i].Num_Records (nlocation)) goto path_error;
			if (i < max_paths) {
				if (!board_path [i].Num_Records (nstop)) goto path_error;
				if (!alight_path [i].Num_Records (nstop)) goto path_error;
			}
		}
	} else if (walk_net || bike_net) {
		if (!node_path [0].Num_Records (nnode)) goto path_error;
	}
	return;

path_error:
	Error ("Insufficient Memory for Path Building data");

mem_error:
	Error ("Insufficient Memory for Time of Day data");

dir_error:
	Error ("Accessing Directional Link Records");
}
