//*********************************************************
//	Read_Trip.cpp - Read the Trip File
//*********************************************************

#include "Router.hpp"

//---------------------------------------------------------
//	Read_Trip
//---------------------------------------------------------

void Router::Read_Trip (void)
{
	int stat, last_traveler, traveler, min_start;
	int hhold_id, person_id, trip, purpose, mode, veh_id;
	int start, arrive, origin, destination, type;
	bool skip = false;

	Location_Data *loc_ptr;
	Vehicle_Data *veh_ptr;
	Household_Data *hh_ptr;

	//---- process each trip ----

	last_traveler = 0;

	Show_Message ("Reading %s -- Record", trip_file.File_Type ());
	Set_Progress (1000);

	while (trip_file.Read ()) {
		Show_Progress ();
		nrecord++;

		hhold_id = trip_file.Household ();

		//---- check the household list ----

		if (hhlist_flag || hhold_flag) {
			hh_ptr = household_data.Get (hhold_id);

			if (hh_ptr == NULL) {
				if (hhlist_flag) {
					if (nhh_proc >= nhh_list) break;
					continue;					
				}
				Error ("A Household Record was Not Found for Household %d", hhold_id);
			}
			if (hhold_flag) {
				type = hh_ptr->Type ();
				value_walk = walk_value [type];
				value_bike = bike_value [type];
				value_time = time_value [type];
				value_wait = wait_value [type];
				value_xfer = xfer_value [type];
				value_distance = distance_value [type];
				value_cost = cost_value [type];
				xfer_imped = imped_xfer [type];
				rail_bias = bias_rail [type];
                max_walk = walk_max [type];
				max_bike = bike_max [type];
				max_wait = wait_max [type];
				max_transfers = xfer_max [type];
				max_paths = path_max [type];
				max_parkride = parkride_max [type];

				walk_flag = (max_walk != 0);
				bike_flag = (max_bike != 0);
				wait_flag = (max_wait != 0);
				bias_flag = (rail_bias != 100);
			}
		}

		//---- read the remaining fields ----

		person_id = trip_file.Person ();
		trip = trip_file.Trip ();
		purpose = trip_file.Purpose ();
		mode = trip_file.Mode ();
		veh_id = trip_file.Vehicle ();
		origin = trip_file.Origin ();
		destination = trip_file.Destination ();

		//---- check for a new traveler ----

		traveler = hhold_id * 100 + person_id;

		if (traveler != last_traveler) {
			last_traveler = traveler;
			nhh_proc++;
			min_start = 0;
			skip = false;
		} else {
			if (skip) goto path_problem;
		}
		if (origin == destination) continue;

		plan_file.Traveler (traveler);
		plan_file.Trip (trip);
		plan_file.Leg (0);

		nprocess++;

		memset (&trip_org, '\0', sizeof (trip_org));
		memset (&trip_des, '\0', sizeof (trip_des));

		//---- set the origin ----

		loc_ptr = location_data.Get (origin);

		if (loc_ptr == NULL) {
			Error ("Location %d was Not Found in the Location File", origin);
		}
		trip_org.Rec (location_data.Record_Index ());
		trip_org.ID (origin);
		trip_org.Link (loc_ptr->Link ());
		trip_org.Offset (loc_ptr->Offset ());
		trip_org.Type (LOCATION_ID);

		start = trip_time.Step (trip_file.Start ());
		if (start < 0) {
			Error ("Converting Start Time %s for Household %d", trip_file.Start (), hhold_id);
		}
		start = Round (start);

		trip_org.TOD (start);
		trip_org.Cum (1);

		//---- set the destination ----

		loc_ptr = location_data.Get (destination);

		if (loc_ptr == NULL) {
			Error ("Location %d was Not Found in the Location File", destination);
		}
		trip_des.Rec (location_data.Record_Index ());
		trip_des.ID (destination);
		trip_des.Link (loc_ptr->Link ());
		trip_des.Offset (loc_ptr->Offset ());
		trip_des.Type (LOCATION_ID);
		trip_des.Cum (MAX_INTEGER);

		arrive = trip_time.Step (trip_file.Arrive ());
		if (arrive < 0) {
			Error ("Converting Arrival Time %s for Household %d", trip_file.Arrive (), hhold_id);
		}
		arrive = Round (arrive);

		if (ignore_time) {
			max_tod = MAX_INTEGER;
		} else {
//			max_tod = (arrive + max_end_time [purpose]) << RESOLUTION;
			max_tod = arrive;
		}

		//---- check the path mode ----

		stat = 0;
		if (mode < MAX_MODE && !select_mode [mode]) goto path_problem;

		if (mode_flag) {
			mode = new_mode;
		}

		//---- get the vehicle record ----

		if (mode == DRIVE_ALONE || mode == PNR_OUT || mode == PNR_IN || 
			mode == CARPOOL2 || mode == CARPOOL3 || mode == CARPOOL4) {
			if (veh_id <= 0 || (veh_ptr = vehicle_data.Get (veh_id)) == NULL) {
				stat = Set_Problem (ACCESS_PROBLEM);
				goto path_problem;
			}
		}

		//---- build the path ----

		time_flag = dist_flag = length_flag = zero_flag = wait_time_flag = access_flag = false;

		switch (mode) {
			case ALL_WALK:		//---- walk ----
				stat = Node_Plan (WALK);
				break;
			case DRIVE_ALONE:		//---- drive ----
				stat = Drive_Plan ((Access_Type) veh_ptr->Type (), veh_ptr);
				break;
			case RAIL_TRANSIT:		//---- walk to light rail ----
				stat = Transit_Plan ();
				break;
			case TRANSIT:		//---- walk to transit ----
				bias_flag = false;
				stat = Transit_Plan ();
				break;
			case PNR_OUT:		//---- drive to transit ----
				stat = Park_Ride_Plan (veh_ptr);
				break;
			case PNR_IN:		//---- transit to drive ----
				stat = Park_Ride_Return (veh_ptr);
				break;
			case BICYCLE:		//---- bike ----
				stat = Node_Plan (BIKE);
				break;
			case MAGIC_MOVE:		//---- magic move ----
				stat = Magic_Move (arrive, 2);
				break;
			case SCHOOL_BUS:		//---- school bus ----
				stat = Magic_Move (arrive, 1);
				break;
			case CARPOOL2:			//---- carpool 2+ ----
				stat = Drive_Plan (HOV2, veh_ptr);
				break;
			case CARPOOL3:			//---- carpool 3+ ----
				stat = Drive_Plan (HOV3, veh_ptr);
				break;
			case CARPOOL4:			//---- carpool 4+ ----
				stat = Drive_Plan (HOV4, veh_ptr);
				break;
			default:
				stat = Set_Problem (MODE_PROBLEM);
				break;
		}
		if (!stat && !walk_detail && walk_active) {
			stat = Save_Plan (&walk_org, &trip_des, Plan_File::WALK_MODE);
		}
		if (stat) {
			if (!ignore_errors) goto path_problem;
			if (veh_id > 0) {
				veh_ptr->Location (access_data [parking_access [trip_des.Rec ()]->To_List ()]->From_ID ());
			}
			if (Magic_Move (start, 2)) {
				skip = true;
				goto path_problem;
			}
			nmagic++;
		}
		min_start = trip_des.TOD ();

path_problem:
		if (stat) {
			if (!ignore_errors) {
				skip = true;
			}
			if (problem_flag) {
				problem_file.Time (trip_file.Start ());
				problem_file.Link (0);
				problem_file.Household (hhold_id);
				problem_file.Person (person_id);
				problem_file.Trip (trip);
				problem_file.Mode (mode);
				problem_file.Problem (stat);
				problem_file.Start (trip_file.Start ());
				problem_file.Origin (origin);
				problem_file.Arrive (trip_file.Arrive ());
				problem_file.Destination (destination);

				problem_file.Write ();
			}
		}
	}
	End_Progress ();

	trip_file.Close ();
}
