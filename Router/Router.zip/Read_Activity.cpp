//*********************************************************
//	Read_Activity.cpp - Read the Activity File
//*********************************************************

#include "Router.hpp"

#include "Scanf.hpp"

//---------------------------------------------------------
//	Read_Activity
//---------------------------------------------------------

void Router::Read_Activity (void)
{
	int stat, last_hh, last_person;
	int start, duration, stop_time, trip, type;
	bool skip = false;

	int hhold_id, person_id, activity_id;
	double lower_start, upper_start, lower_dur, upper_dur;
	int mode, veh_id, act_loc, org_loc, num_pass;

	Location_Data *loc_ptr;
	Vehicle_Data *veh_ptr;
	Household_Data *hh_ptr;

	walk_active = false;
	last_hh = last_person = start = 0;

	memset (&trip_org, '\0', sizeof (trip_org));
	org_loc = 0;

	Show_Message ("Reading %s -- Record", activity_file.File_Type ());
	Set_Progress (2000);

	while (activity_file.Read ()) {
		Show_Progress ();
		nrecord++;

		//--- get the activity record ----

		tscanf (activity_file.Record (), "%d\t%d\t%d\t%*d\t%*d\t%lf\t%lf\t%*lf\t%*lf\t%*lf\t%*lf\t%*lf\t%*lf\t%lf\t%lf\t%*lf\t%*lf\t%d\t%d\t%*d\t%d\t%d", 
			&hhold_id, &person_id, &activity_id, &lower_start, &upper_start, &lower_dur, &upper_dur, &mode, &veh_id, &act_loc, &num_pass);

		//---- check the household list ----

		if (hhlist_flag || hhold_flag) {
			hh_ptr = household_data.Get (hhold_id);

			if (hh_ptr == NULL) {
				if (hhlist_flag) {
					if (nhh_proc >= nhh_list) break;
					continue;					
				}
				Error ("A Household Record was Not Found for Household %d", hhold_id);
			}
			if (hhold_flag) {
				type = hh_ptr->Type ();
				value_walk = walk_value [type];
				value_bike = bike_value [type];
				value_time = time_value [type];
				value_wait = wait_value [type];
				value_xfer = xfer_value [type];
				value_distance = distance_value [type];
				value_cost = cost_value [type];
				xfer_imped = imped_xfer [type];
				rail_bias = bias_rail [type];
                max_walk = walk_max [type];
				max_bike = bike_max [type];
				max_wait = wait_max [type];
				max_transfers = xfer_max [type];
				max_paths = path_max [type];
				max_parkride = parkride_max [type];

				walk_flag = (max_walk != 0);
				bike_flag = (max_bike != 0);
				wait_flag = (max_wait != 0);
				bias_flag = (rail_bias != 100);
			}
		}
		nprocess++;
		stat = 0;
		memset (&trip_des, '\0', sizeof (trip_des));

		//--- convert to internal values ----

		loc_ptr = location_data.Get (act_loc);

		if (loc_ptr == NULL) {
			Error ("Location %d was Not Found in the Location File", act_loc);
		}
		trip_des.Rec (location_data.Record_Index ());
		trip_des.ID (act_loc);
		trip_des.Link (loc_ptr->Link ());
		trip_des.Offset (loc_ptr->Offset ());
		trip_des.Type (LOCATION_ID);
		
		start = Round (trip_time.Step ((lower_start + upper_start) / 2.0));

		//---- check for a new traveler ----

		if (hhold_id != last_hh || person_id != last_person) {
			last_hh = hhold_id;
			last_person = person_id;
			nhh_proc++;
			trip = 1;
			skip = false;
			if (lower_start == 0.0) start = 0;
		} else {
			if (skip) goto path_problem;

			plan_file.Trip (trip++);
			plan_file.Leg (0);

			if (trip_org.ID () != trip_des.ID ()) {
				if (ignore_time) {
					max_tod = MAX_INTEGER;
				} else {
					max_tod = Round (trip_time.Step (upper_start));
				}
				trip_des.Cum (MAX_INTEGER);

				//---- check the path mode ----

				stat = 0;
				if (mode < MAX_MODE && !select_mode [mode]) goto path_problem;

				if (mode_flag) {
					mode = new_mode;
				}

				//---- get the vehicle record ----

				if (mode == DRIVE_ALONE || mode == PNR_OUT || mode == PNR_IN || mode == CARPOOL2 ||
					mode == CARPOOL3 || mode == CARPOOL4) {
					if (veh_id <= 0 || (veh_ptr = vehicle_data.Get (veh_id)) == NULL) {
						stat = Set_Problem (ACCESS_PROBLEM);
						goto path_problem;
					}
				}

				//---- build the path ----

				time_flag = dist_flag = length_flag = zero_flag = wait_time_flag = access_flag = false;

				switch (mode) {
					case ALL_WALK:		//---- walk ----
						stat = Node_Plan (WALK);
						break;
					case DRIVE_ALONE:		//---- drive ----
						stat = Drive_Plan ((Access_Type) veh_ptr->Type (), veh_ptr);
						break;
					case RAIL_TRANSIT:		//---- walk to light rail ----
						stat = Transit_Plan ();
						break;
					case TRANSIT:		//---- walk to transit ----
						bias_flag = false;
						stat = Transit_Plan ();
						break;
					case PNR_OUT:		//---- drive to transit ----
						stat = Park_Ride_Plan (veh_ptr);
						break;
					case PNR_IN:		//---- transit to drive ----
						stat = Park_Ride_Return (veh_ptr);
						break;
					case BICYCLE:		//---- bike ----
						stat = Node_Plan (BIKE);
						break;
					case MAGIC_MOVE:		//---- magic move ----
						stat = Magic_Move (start, 2);
						break;
					case SCHOOL_BUS:		//---- school bus ----
						stat = Magic_Move (start, 1);
						break;
					case CARPOOL2:			//---- carpool 2+ ----
						stat = Drive_Plan (HOV2, veh_ptr);
						break;
					case CARPOOL3:			//---- carpool 3+ ----
						stat = Drive_Plan (HOV3, veh_ptr);
						break;
					case CARPOOL4:			//---- carpool 4+ ----
						stat = Drive_Plan (HOV4, veh_ptr);
						break;
					default:
						stat = Set_Problem (MODE_PROBLEM);
						break;
				}
				if (!stat && !walk_detail && walk_active) {
					stat = Save_Plan (&walk_org, &trip_des, Plan_File::WALK_MODE);
				}
				if (stat) {
					if (!ignore_errors) goto path_problem;
					if (veh_id > 0) {
						veh_ptr->Location (access_data [parking_access [trip_des.Rec ()]->To_List ()]->From_ID ());
					}
					if (Magic_Move (start, 2)) {
						skip = true;
						goto path_problem;
					}
					nmagic++;
				}
				start = trip_des.TOD ();
			}
		}
		
		//---- output the activity ----

		duration = Round (trip_time.Step ((lower_dur + upper_dur) / 2.0));
		stop_time = start + duration;

		plan_file.Traveler (person_id);
		plan_file.Trip (trip++);
		plan_file.Leg (1);
		plan_file.Time (Resolve (start));
		plan_file.Start_ID (act_loc);
		plan_file.Start_Type (LOCATION_ID);
		plan_file.End_ID (act_loc);
		plan_file.End_Type (LOCATION_ID);
		plan_file.Duration (Resolve (duration));
		plan_file.Stop_Time (Resolve (stop_time));
		plan_file.Cost (0);
		plan_file.GCF (0);
		plan_file.Driver_Flag (0);
		plan_file.Mode (Plan_File::ACTIVITY_MODE);
		plan_file.Tokens (0);

		if (save_plans && !plan_file.Write ()) {
			Error ("Writing Plan File");
		}
		trip_org = trip_des;
		trip_org.TOD (stop_time);
		trip_org.Cum (1);
		trip_org.Cost (0);
		trip_org.Time (0);
		trip_org.Prev (0);
		trip_org.Path (0);
		trip_org.Layer (0);

path_problem:
		if (stat) {
			if (!ignore_errors) {
				skip = true;
			}
			if (problem_flag) {
				problem_file.Time (trip_time.Format_Step (Resolve (trip_org.TOD ())));
				problem_file.Link (0);
				problem_file.Household (hhold_id);
				problem_file.Person (person_id);
				problem_file.Trip (activity_id);
				problem_file.Mode (mode);
				problem_file.Problem (stat);
				problem_file.Start (trip_time.Format_Step (Resolve (trip_org.TOD ())));
				problem_file.Origin (org_loc);
				problem_file.Arrive (trip_time.Format_Step (Resolve (start)));
				problem_file.Destination (act_loc);

				problem_file.Write ();
			}
		}
		org_loc = trip_org.ID ();
	}
	End_Progress ();

	activity_file.Close ();
}
